package com.example.timetable

annotation class PrimaryKey